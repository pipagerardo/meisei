#include "stdio.h"
#include "string.h"
#include "zlib.h"

int main(void)
{
	unsigned char wave[300];
	unsigned char data[0x10000];
	unsigned char dest[0x10000];
	int i=0,j=0,k=0;
	FILE* fd;
	uLongf destlen=0xffff;
	
	#define DOFN(z,w,x,y) \
		/* wave */ \
		fd=fopen(x,"rb"); \
		if (fd==NULL||!fread(wave,1,300,fd)) printf("err"); \
		fclose(fd); memcpy(data+i,wave+44,0x100); i+=0x100; \
		data[i++]=w; /* amp */ \
		memcpy(data+i,y,strlen(y)); i+=strlen(y); data[i++]=0; /* preset name */ \
		if (z) k=j; j++ /* default */
	
	/* presets by Wolf */
	DOFN(0,155,"basic_cosine.wav",		"Ana Cosine");
	DOFN(0,110,"an_isaw1.wav",			"Ana Inv Saw 1");
	DOFN(0,110,"an_isaw2.wav",			"Ana Inv Saw 2");
	DOFN(0,110,"an_isaw3.wav",			"Ana Inv Saw 3");
	DOFN(0,110,"an_isaw4.wav",			"Ana Inv Saw 4");
	DOFN(0,110,"an_isaw5.wav",			"Ana Inv Saw 5");
	DOFN(0,110,"an_isaw6.wav",			"Ana Inv Saw 6");
	DOFN(0,110,"an_isaw7.wav",			"Ana Inv Saw 7");
	DOFN(0,110,"an_isaw8.wav",			"Ana Inv Saw 8");
	DOFN(0,110,"an_isaw9.wav",			"Ana Inv Saw 9");
	DOFN(0,110,"an_isaw10.wav",			"Ana Inv Saw 10");
	DOFN(0,125,"an_i2saw1.wav",			"Ana Inv2 Saw 1");
	DOFN(0,150,"an_i2saw2.wav",			"Ana Inv2 Saw 2");
	DOFN(0,200,"an_i2saw3.wav",			"Ana Inv2 Saw 3");
	DOFN(0,105,"an_i3saw1.wav",			"Ana Inv3 Saw 1");
	DOFN(0,110,"an_i3saw2.wav",			"Ana Inv3 Saw 2");
	DOFN(0,110,"an_i3saw3.wav",			"Ana Inv3 Saw 3");
	DOFN(0,110,"an_i3saw4.wav",			"Ana Inv3 Saw 4");
	DOFN(0,160,"an_pulse1.wav",			"Ana Pulse 1");
	DOFN(0,140,"an_pulse2.wav",			"Ana Pulse 2");
	DOFN(0,130,"an_pulse3.wav",			"Ana Pulse 3");
	DOFN(0,125,"an_pulse4.wav",			"Ana Pulse 4");
	DOFN(0,119,"an_pulse5.wav",			"Ana Pulse 5");
	DOFN(0,114,"an_pulse6.wav",			"Ana Pulse 6");
	DOFN(0,111,"an_pulse7.wav",			"Ana Pulse 7");
	DOFN(0,107,"an_pulse8.wav",			"Ana Pulse 8");
	DOFN(0,103,"an_pulse9.wav",			"Ana Pulse 9");
	DOFN(1,100,"an_square.wav",			"Ana Square");
	DOFN(0,100,"an_syncsaw1.wav",		"Ana SyncSaw 1");
	DOFN(0,100,"an_syncsaw2.wav",		"Ana SyncSaw 2");
	DOFN(0,100,"an_syncsaw3.wav",		"Ana SyncSaw 3");
	DOFN(0,100,"an_syncsaw4.wav",		"Ana SyncSaw 4");
	DOFN(0,100,"an_syncsaw5.wav",		"Ana SyncSaw 5");
	DOFN(0,100,"an_syncsaw6.wav",		"Ana SyncSaw 6");
	DOFN(0,100,"an_syncsaw7.wav",		"Ana SyncSaw 7");
	DOFN(0,100,"an_syncsaw8.wav",		"Ana SyncSaw 8");
	DOFN(0,100,"an_syncsaw9.wav",		"Ana SyncSaw 9");
	DOFN(0,100,"an_syncsaw10.wav",		"Ana SyncSaw 10");
	DOFN(0,100,"an_syncsaw11.wav",		"Ana SyncSaw 11");
	DOFN(0,100,"an_syncsaw12.wav",		"Ana SyncSaw 12");
	DOFN(0,100,"an_syncsaw13.wav",		"Ana SyncSaw 13");
	DOFN(0,100,"an_syncsaw14.wav",		"Ana SyncSaw 14");
	DOFN(0,100,"an_syncsaw15.wav",		"Ana SyncSaw 15");
	DOFN(0,100,"an_syncsaw16.wav",		"Ana SyncSaw 16");
	DOFN(0,100,"an_syncsaw17.wav",		"Ana SyncSaw 17");
	DOFN(0,100,"an_syncsaw18.wav",		"Ana SyncSaw 18");
	DOFN(0,100,"an_syncsaw19.wav",		"Ana SyncSaw 19");
	DOFN(0,100,"an_syncsaw20.wav",		"Ana SyncSaw 20");
	DOFN(0,100,"an_syncsaw21.wav",		"Ana SyncSaw 21");
	DOFN(0,200,"basic_tri.wav",			"Ana Triangle");
	DOFN(0,165,"basic_tricos.wav",		"Ana TriCos");
	DOFN(0,140,"fm_bass.wav",			"FM Bass");
	DOFN(0,140,"fm_bass2.wav",			"FM Bass 2");
	DOFN(0,160,"fm_brass.wav",			"FM Brass");
	DOFN(0,170,"fm_clarinet.wav",		"FM Clarinet");
	DOFN(0,125,"fm_ebass.wav",			"FM Ebass");
	DOFN(0,120,"fm_epiano.wav",			"FM Epiano");
	DOFN(0,180,"fm_flute.wav",			"FM Flute");
	DOFN(0,165,"fm_guitar.wav",			"FM Guitar");
	DOFN(0,150,"fm_harpsichord.wav",	"FM Harpsichord");
	DOFN(0,175,"fm_horn.wav",			"FM Horn");
	DOFN(0,200,"fm_microbrass.wav",		"FM Microbass");
	DOFN(0,145,"fm_oboe.wav",			"FM Oboe");
	DOFN(0,150,"fm_organ.wav",			"FM Organ");
	DOFN(0,125,"fm_piano.wav",			"FM Piano");
	DOFN(0,135,"fm_piano2.wav",			"FM Piano 2");
	DOFN(0,200,"fm_steel.wav",			"FM Steel Drum");
	DOFN(0,190,"fm_synth.wav",			"FM Synth");
	DOFN(0,180,"fm_synbas.wav",			"FM Synth Bass");
	DOFN(0,160,"fm_trumpet.wav",		"FM Trumpet");
	DOFN(0,135,"fm_vib.wav",			"FM Vibraphone");
	DOFN(0,180,"fm_violin.wav",			"FM Violin");
	DOFN(0,180,"fm_violin_oct1.wav",	"FM Violin Oct1");
	DOFN(0,180,"fm_violin_oct2.wav",	"FM Violin Oct2");
	DOFN(0,180,"fm_violin_oct3.wav",	"FM Violin Oct3");
	DOFN(0,120,"scc_bass.wav",			"SCC Bass");
	DOFN(0,140,"scc_casual.wav",		"SCC Casual");
	DOFN(0,135,"scc_church.wav",		"SCC Church");
	DOFN(0,125,"scc_halftrisin.wav",	"SCC Half TriSin");
	DOFN(0,120,"scc_resonator.wav",		"SCC Resonator");
	DOFN(0,110,"scc_rough3.wav",		"SCC Rough 3");
	DOFN(0,120,"scc_saw.wav",			"SCC Saw");
	DOFN(0,130,"scc_vibraphone.wav",	"SCC Vibraphone");
	DOFN(0,130,"scc_voice.wav",			"SCC Voice");
	DOFN(0,100,"custom.wav",			"Custom");
	
	#undef DOFN
	
	printf("total: %d .. size: %d .. default: %d\n",j,i,k);
	
	if (compress(dest,&destlen,data,(uLong)i)!=Z_OK) {
		printf("errc");
	}
	
	i=destlen;
	printf("compressed size: %d\n",i);
	
	fd=fopen("psg_presets.bin","wb");
	fwrite(dest,1,i,fd);
	fclose(fd);
	
	return 0;
}
